using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace RazorPageExample.Pages
{
    public class ContactModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
